/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.user.controller;

import com.fraud.algorithm.controller.FeatureExtractionAlgorithm;
import com.fraud.algorithm.controller.LookupTechnique;
import com.fraud.algorithm.controller.LookupTechniqueResult;
import com.fraud.algorithm.controller.ResultModel;
import com.fraud.database.dto.UserInfoTableDTO;
import com.fraud.database.services.UserInfoTableService;
import com.fraud.home.controller.Configuration;
import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author aniket
 */
@Controller
public class UserController {

    @InitBinder
    public void initBinder(WebDataBinder webDataBinder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);
        webDataBinder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    @RequestMapping(value = "setup_dashboard.htm", method = RequestMethod.GET)
    public ModelAndView setupDashboard(HttpServletRequest request) {
        HttpSession session = request.getSession();
        String useremail = (String) session.getAttribute("useremail");
        UserInfoTableDTO userInfo = UserInfoTableService.getUserInfoDTO(useremail);
        Integer userId = userInfo.getId();
        String path = "/home/aniket/Project/2018-Proejcts/FraudDetection/web/style/"+userId;
        path = path + "/profile";
        ModelAndView modelAndView = new ModelAndView("user/dashboard");
        File folder = new File(path);
        if (folder.exists()) {
            modelAndView.addObject("profileImagePath", userId);
        } else {
            modelAndView.addObject("profileImagePath", null);
        }
        return modelAndView;
    }

    @RequestMapping(value = "setup_lookup_technique.htm", method = RequestMethod.GET)
    public ModelAndView setupLookupTechnicque() {
        ModelAndView modelAndView = new ModelAndView("user/lookup_technique");
        return modelAndView;
    }

    @RequestMapping(value = "setup_data_mining_technique.htm", method = RequestMethod.GET)
    public ModelAndView setupDataMiningTechnicque() {
        ModelAndView modelAndView = new ModelAndView("user/data_mining_technique");
        return modelAndView;
    }

    @RequestMapping(value = "submit_lookup_technique.htm", method = RequestMethod.POST)
    public ModelAndView submitLookupTechnicque(@RequestParam("websiteurl") String websiteurl) {
        System.out.println("websiteurl = " + websiteurl);
        LookupTechniqueResult result = LookupTechnique.findFraudWebsite(websiteurl.trim());
        System.out.println("result = " + result);
        ModelAndView modelAndView = new ModelAndView("user/lookup_technique_result");
        modelAndView.addObject("result", result);
        modelAndView.addObject("urlLink", websiteurl);
        return modelAndView;
    }

    @RequestMapping(value = "logout.htm", method = RequestMethod.GET)
    public void logout(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession();
            session.removeAttribute("useremail");
            session.invalidate();
            response.sendRedirect("../home/setup_user_login.htm");
        } catch (Exception ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @RequestMapping(value = "submit_upload_file.htm", method = RequestMethod.POST)
    public ModelAndView submitUploadFile(@RequestParam CommonsMultipartFile dataFile, HttpServletRequest request) {
        ModelAndView modelAndView = null;
        try {
            InputStream inputStream = dataFile.getInputStream();
            byte[] toByteArray = IOUtils.toByteArray(inputStream);
            String stringData = new String(toByteArray);
            ArrayList<ResultModel> list = FeatureExtractionAlgorithm.applyAlgorithm(stringData);
            modelAndView = new ModelAndView("user/alogithm_result");
            modelAndView.addObject("list", list);
            return modelAndView;
        } catch (Exception ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return modelAndView;
    }
}
