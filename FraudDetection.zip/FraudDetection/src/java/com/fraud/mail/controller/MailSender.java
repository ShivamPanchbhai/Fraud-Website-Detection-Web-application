/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.mail.controller;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author aniket
 */
public class MailSender {

    public static final String fromEmail = "dldgroup2017@gmail.com";

    public static void send(String toEmailId, String subject, String mailBody) {
        try {
            MailManager mailManager = MailManager.getInstance();
            Session session = mailManager.getSession();
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(MailSender.fromEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmailId));
            message.setSubject(subject);
            message.setText(mailBody);
            Transport.send(message);
        } catch (Exception ex) {
            Logger.getLogger(MailSender.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
