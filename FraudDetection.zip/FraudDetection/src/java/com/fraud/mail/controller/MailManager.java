/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.mail.controller;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

/**
 *
 * @author aniket
 */
public class MailManager {

    private static final String userName = "dldgroup2017@gmail.com";
    private static final String password = "dldgroup@2018";
    private static final String host = "smtp.gmail.com";
    private static MailManager mailManager;
    private Session session;

    private MailManager() {
        init();
    }

    public static MailManager getInstance() {
        if (mailManager == null) {
            mailManager = new MailManager();
        }
        return mailManager;
    }

    private void init() {
        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.auth", "true");
        properties.setProperty("mail.debug", "true");
        properties.setProperty("mail.smtp.starttls.enable", "true");
        properties.setProperty("mail.smtp.host", host);
        properties.setProperty("mail.smtp.port", "587");
        session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(userName, password); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }

    public Session getSession() {
        return session;
    }

    public static String getUserLoginInfoMailBody(String username, String password) {
        String mailBody = "User Name :- " + username + " Password :- " + password;
        return mailBody;
    }

    public static String getFileSecrectKeyMailBody(String username, int userId, String key) {
        String mailBody = "User Name :- " + username + "  User Id :- " + userId + "  Key :- " + key;
        return mailBody;
    }

    public static String getFileLekageInfoMailBody(String fileName, String userName, int userId) {
        String message = "Fake Object is try to lekage file by follwing user account.  ";
        String mailBody = "  File Name :- " + fileName + " User Name :- " + userName + " User Id :- " + userId;
        mailBody = message + mailBody;
        return mailBody;
    }
}
