/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.database.controller;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author aniket
 */
public class DatabaseOperation {

    private static SessionFactory sessionFactory;
    private static Session session;
    private static Transaction transaction;

    public DatabaseOperation() {
        start();
    }

    public static Integer save(Object object) {
        transaction = session.beginTransaction();
        Integer id = (Integer) session.save(object);
        transaction.commit();
        return id;
    }

    public static void update(Object object) {
        session.flush();
        session.clear();
        session.update(object);
        transaction = session.beginTransaction();
        transaction.commit();
    }

    public static void delete(Object object) {
        session.delete(object);
    }

    public static void start() {
        sessionFactory = HibernateUtility.getSessionFactory();
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
    }

    public static void stop() {
        sessionFactory.close();
//        session.close();
    }

    public static Session getSession() {
        return session;
    }

    public static Transaction getTransaction() {
        return transaction;
    }

    public static Criteria getCriteria(Class classType) {
        Criteria criteria = session.createCriteria(classType);
        return criteria;
    }
}
