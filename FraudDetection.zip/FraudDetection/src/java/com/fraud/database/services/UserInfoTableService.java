/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.database.services;

import com.fraud.database.controller.DatabaseOperation;
import com.fraud.database.dto.UserInfoTableDTO;
import com.fraud.database.pojo.UserInfoTable;
import static com.fraud.database.services.TableService.COLUMN_ACTIVE;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author aniket
 */
public class UserInfoTableService extends TableService {

    public static final Class USER_TABLE = UserInfoTable.class;
    public static final String USERNAME = "emailId";
    public static final String PASSWORD = "password";
    public static final String EMAIL_ID = "emailId";
    public static final String USER_ID = "id";

    public static Integer add(UserInfoTableDTO userInfoTableDTO) {
        UserInfoTable toTable = userInfoTableDTO.toTable();
        Integer id = DatabaseOperation.save(toTable);
        return id;
    }
    
    public static void update(UserInfoTableDTO userInfoTableDTO) {
        UserInfoTable toTable = userInfoTableDTO.toTable();
        DatabaseOperation.update(toTable);
    }

    public static boolean verifyEmailId(String emailId) {
        Criteria criteria = DatabaseOperation.getCriteria(USER_TABLE);
        Criterion activeCriterion = Restrictions.eq(COLUMN_ACTIVE, Boolean.TRUE);
        Criterion emailIdCriterion = Restrictions.eq(EMAIL_ID, emailId.trim());
        criteria.add(activeCriterion);
        criteria.add(emailIdCriterion);
        List list = criteria.list();
        if (list != null && list.size() > 0) {
            return true;
        }
        return false;
    }

    public static UserInfoTableDTO getUserInfoDTO(String emailId) {
        Criteria criteria = DatabaseOperation.getCriteria(USER_TABLE);
        Criterion activeCriterion = Restrictions.eq(COLUMN_ACTIVE, Boolean.TRUE);
        Criterion emailIdCriterion = Restrictions.eq(EMAIL_ID, emailId.trim());
        criteria.add(activeCriterion);
        criteria.add(emailIdCriterion);
        List list = criteria.list();
        if (list != null && list.size() > 0) {
            UserInfoTable userInfoTable = (UserInfoTable) list.get(0);
            UserInfoTableDTO infoTableDTO = new UserInfoTableDTO(userInfoTable);
            return infoTableDTO;
        }
        return null;
    }

    public static UserInfoTableDTO getUserInfoDTOById(Integer userId) {
        Criteria criteria = DatabaseOperation.getCriteria(USER_TABLE);
        Criterion activeCriterion = Restrictions.eq(COLUMN_ACTIVE, Boolean.TRUE);
        Criterion userIdCriterion = Restrictions.eq(USER_ID, userId);
        criteria.add(activeCriterion);
        criteria.add(userIdCriterion);
        List list = criteria.list();
        if (list != null && list.size() == 1) {
            UserInfoTable userInfoTable = (UserInfoTable) list.get(0);
            UserInfoTableDTO infoTableDTO = new UserInfoTableDTO(userInfoTable);
            return infoTableDTO;
        }
        return null;
    }

    public static ArrayList<UserInfoTableDTO> getUserInfoDTOList() {
        ArrayList<UserInfoTableDTO> arrayList = new ArrayList<>();
        Criteria criteria = DatabaseOperation.getCriteria(USER_TABLE);
        Criterion activeCriterion = Restrictions.eq(COLUMN_ACTIVE, Boolean.TRUE);
        criteria.add(activeCriterion);
        List list = criteria.list();
        if (list != null && list.size() > 0) {
            for (Object object : list) {
                UserInfoTable userInfoTable = (UserInfoTable) object;
                UserInfoTableDTO infoTableDTO = new UserInfoTableDTO(userInfoTable);
                arrayList.add(infoTableDTO);
            }
        }
        return arrayList;
    }

    public static boolean verifyLogin(String username, String password) {
        Criteria criteria = DatabaseOperation.getCriteria(USER_TABLE);
        Criterion activeCriterion = Restrictions.eq(COLUMN_ACTIVE, Boolean.TRUE);
        Criterion usernameCriterion = Restrictions.eq(USERNAME, username);
        Criterion passwordCriterion = Restrictions.eq(PASSWORD, password);
        criteria.add(activeCriterion);
        criteria.add(usernameCriterion);
        criteria.add(passwordCriterion);
        List list = criteria.list();
        if (list != null && list.size() > 0) {
            return true;
        }
        return false;
    }
}
