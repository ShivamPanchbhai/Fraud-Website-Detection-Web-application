/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.database.services;

import com.fraud.database.controller.DatabaseOperation;
import com.fraud.database.pojo.AdminInfoTable;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author aniket
 */
public class AdminInfoTableService extends TableService {

    public static final Class ADMIN_TABLE = AdminInfoTable.class;
    public static final String USERNAME = "emailId";
    public static final String PASSWORD = "password";

    public static boolean verifyLogin(String username, String password) {
        Criteria criteria = DatabaseOperation.getCriteria(ADMIN_TABLE);
        Criterion activeCriterion = Restrictions.eq(COLUMN_ACTIVE, Boolean.TRUE);
        Criterion usernameCriterion = Restrictions.eq(USERNAME, username);
        Criterion passwordCriterion = Restrictions.eq(PASSWORD, password);
        criteria.add(activeCriterion);
        criteria.add(usernameCriterion);
        criteria.add(passwordCriterion);
        List list = criteria.list();
        if (list != null && list.size() > 0) {
            return true;
        }
        return false;
    }
}
