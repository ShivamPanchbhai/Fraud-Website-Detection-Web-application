/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.database.dto;

import com.fraud.database.pojo.UserInfoTable;
import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author aniket
 */
public class UserInfoTableDTO extends UserInfoTable {


    public UserInfoTableDTO() {
    }

    public UserInfoTableDTO(UserInfoTable userInfoTable) {
        this.setActive(userInfoTable.getActive());
        this.setAddress(userInfoTable.getAddress());
        this.setCity(userInfoTable.getCity());
        this.setCountry(userInfoTable.getCountry());
        this.setEmailId(userInfoTable.getEmailId());
        this.setId(userInfoTable.getId());
        this.setName(userInfoTable.getName());
        this.setPassword(userInfoTable.getPassword());
        this.setPhone(userInfoTable.getPhone());
        this.setPincode(userInfoTable.getPincode());
        this.setState(userInfoTable.getState());
    }

    public UserInfoTable toTable() {
        try {
            UserInfoTable userInfoTable = new UserInfoTable();
            BeanUtils.copyProperties(userInfoTable, this);
            return userInfoTable;
        } catch (Exception exception) {
            System.out.println("Exception = " + exception);
        }
        return null;
    }
}
