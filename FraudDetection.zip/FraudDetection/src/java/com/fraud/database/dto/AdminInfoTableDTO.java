/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.database.dto;

import com.fraud.database.pojo.AdminInfoTable;
import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author aniket
 */
public class AdminInfoTableDTO extends AdminInfoTable {

    public AdminInfoTableDTO() {
    }

    public AdminInfoTableDTO(AdminInfoTable adminInfoTable) {
        this.setActive(adminInfoTable.getActive());
        this.setAddress(adminInfoTable.getAddress());
        this.setCity(adminInfoTable.getCity());
        this.setCountry(adminInfoTable.getCountry());
        this.setEmailId(adminInfoTable.getEmailId());
        this.setId(adminInfoTable.getId());
        this.setName(adminInfoTable.getName());
        this.setPassword(adminInfoTable.getPassword());
        this.setPhone(adminInfoTable.getPhone());
        this.setPincode(adminInfoTable.getPincode());
        this.setState(adminInfoTable.getState());
    }

    public AdminInfoTable toTable() {
        try {
            AdminInfoTable adminInfoTable = new AdminInfoTable();
            BeanUtils.copyProperties(adminInfoTable, this);
            return adminInfoTable;
        } catch (Exception exception) {
            System.out.println("Exception = " + exception);
        }
        return null;
    }
}
