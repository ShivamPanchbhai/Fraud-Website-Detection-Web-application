/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.application.listener;

import com.fraud.database.controller.DatabaseOperation;

/**
 * @author aniket
 */
public class ApplicationListenerContext {

    public ApplicationListenerContext() {
        initDatabaseOperationConfiguration();
    }

    private void initDatabaseOperationConfiguration() {
        DatabaseOperation.start();
    }

}
