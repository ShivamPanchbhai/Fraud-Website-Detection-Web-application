/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.algorithm.controller;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aniket
 */
public class FeatureExtractionAlgorithm {

    //https://pdfs.semanticscholar.org/0e3d/3d4432d00a6958cade8c5abe2abed5035a40.pdf
    public static ArrayList<ResultModel> applyAlgorithm(String dataSet) {
        ArrayList<ResultModel> resultModelList = new ArrayList<>();
        String[] split = dataSet.split("\n");
        for (String eachURL : split) {
            String[] split1 = eachURL.split(" ");
            String id = split1[0];
            String url = split1[1];
            ResultModel resultModel = new ResultModel();
            Boolean presenceOfIP = presenceOfIP(url);
            if (presenceOfIP) {
                resultModel.setId(id);
                resultModel.setIsFraud(true);
                resultModel.setUrlName(url);
                resultModel.setReasonforFraud("Presence of IP address in URL");
                resultModelList.add(resultModel);
            } else {
                int noOfDots = noOfDots(url);
                if (noOfDots > 5) {
                    resultModel.setId(id);
                    resultModel.setIsFraud(true);
                    resultModel.setUrlName(url);
                    resultModel.setReasonforFraud("No. of dots Max 5");
                    resultModelList.add(resultModel);
                } else {
                    boolean urlLength = urlLength(url);
                    if (urlLength) {
                        resultModel.setId(id);
                        resultModel.setIsFraud(true);
                        resultModel.setUrlName(url);
                        resultModel.setReasonforFraud("Length of Max 104");
                        resultModelList.add(resultModel);
                    } else {
                        int specialCharCount = specialCharCount(url);
                        if (specialCharCount > 14) {
                            resultModel.setId(id);
                            resultModel.setIsFraud(true);
                            resultModel.setReasonforFraud("Special characters Max 14");
                            resultModel.setUrlName(url);
                            resultModelList.add(resultModel);
                        } else {
                            boolean hostLength = hostLength(url);
                            if (hostLength) {
                                resultModel.setId(id);
                                resultModel.setIsFraud(true);
                                resultModel.setReasonforFraud("Host Max 37");
                                resultModel.setUrlName(url);
                                resultModelList.add(resultModel);
                            } else {
                                boolean hexadecimalChar = hexadecimalChar(url);
                                if (hexadecimalChar) {
                                    resultModel.setId(id);
                                    resultModel.setIsFraud(true);
                                    resultModel.setUrlName(url);
                                    resultModel.setReasonforFraud("Presence of Hexadecimal characters in URL");
                                    resultModelList.add(resultModel);
                                } else {
                                    LookupTechniqueResult validateWebsite = LookupTechnique.findFraudWebsite(url);
                                    if (validateWebsite.getIsFraud() == null) {
                                        resultModel.setId(id);
                                        resultModel.setIsFraud(true);
                                        resultModel.setReasonforFraud("DNS Record Data not available");
                                        resultModel.setUrlName(url);
                                        resultModelList.add(resultModel);
                                    } else {
                                        if (validateWebsite.getIsFraud().equals("Fraud")) {
                                            resultModel.setId(id);
                                            resultModel.setIsFraud(true);
                                            resultModel.setReasonforFraud("DNS Record not available");
                                            resultModel.setUrlName(url);
                                            resultModelList.add(resultModel);
                                        } else {
                                            resultModel.setId(id);
                                            resultModel.setIsFraud(false);
                                            resultModel.setReasonforFraud("DNS Record available");
                                            resultModel.setUrlName(url);
                                            resultModelList.add(resultModel);
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
        }
        System.out.println("resultModelList = " + resultModelList.size());
        for (ResultModel resultModel : resultModelList) {
            System.out.println("resultModel = " + resultModel);
        }
        return resultModelList;
    }

    private static Boolean presenceOfIP(String siteURL) {
        IPAddressValidator addressValidator = new IPAddressValidator();
        boolean validate = addressValidator.validate(siteURL);
        return validate;
    }

    private static int noOfDots(String url) {
        int count = url.length() - url.replaceAll("[.!?]+", "").length();
        return count;
    }

    private static boolean urlLength(String url) {
        int length = url.length();
        if (length > 104) {
            return true;
        } else {
            return false;
        }
    }

    private static int specialCharCount(String yourString) {
        int fullLength = yourString.length();
        String modifiedString = yourString.replaceAll("\\p{Punct}", "");
        int modStringLength = modifiedString.length();
        int numberOfSpecialChars = fullLength - modStringLength;
        System.out.println(numberOfSpecialChars);
        return numberOfSpecialChars;
    }

    private static boolean hostLength(String websiteurl) {
        URL url = null;
        try {
            url = new URL(websiteurl);
        } catch (Exception ex) {
            Logger.getLogger(FeatureExtractionAlgorithm.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (url != null) {
            String host = url.getHost();
            int length = host.length();
            if (length > 37) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    private static boolean hexadecimalChar(String url) {
        HexadecimalValidator validator = new HexadecimalValidator();
        boolean validate = validator.validate(url);
        return validate;
    }
}
