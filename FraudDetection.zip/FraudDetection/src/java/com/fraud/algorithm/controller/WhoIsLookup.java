/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.algorithm.controller;

import java.io.File;
import java.io.FileWriter;
import java.util.Date;
import org.apache.commons.net.whois.WhoisClient;

/**
 *
 * @author aniket
 */
public class WhoIsLookup {

    public static void main(String[] args) {

//      String domain = "ibgitechnology.com";
        String domain = "kits.edu";
//      String domain = "aniketkohaleak.com";
//        StringBuilder sb = new StringBuilder("");
//        WhoisClient wic = new WhoisClient();
//        try {
//            wic.connect(WhoisClient.DEFAULT_HOST);
//            String whoisData1 = wic.query("=" + domain);
//            sb.append(whoisData1);
//            wic.disconnect();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        System.out.println(sb.toString());
        LookupTechniqueResult validateWebsite = validateWebsite(domain.trim());
        System.out.println("validateWebsite = " + validateWebsite);
    }

    public static LookupTechniqueResult validateWebsite(String websiteurl) {
        StringBuilder sb = new StringBuilder("");
        WhoisClient wic = new WhoisClient();
        try {
            wic.connect(WhoisClient.DEFAULT_HOST);
            String whoisData1 = wic.query("=" + websiteurl.trim());
            sb.append(whoisData1);
            wic.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(sb.toString());
        String resultFileDownloadLink = saveWebsiteResultFile(sb.toString().trim());
        LookupTechniqueResult lookupTechniqueResult = parseResturnData(sb.toString().trim());
        lookupTechniqueResult.setResultFileDownloadLink(resultFileDownloadLink.trim());
        return lookupTechniqueResult;
    }

    public static LookupTechniqueResult parseResturnData(String returnData) {
//        System.out.println("returnData = " + returnData);
        LookupTechniqueResult lookupTechniqueResult = new LookupTechniqueResult();
        String[] split = returnData.split("\n");
        for (String eachLine : split) {
            if (eachLine.startsWith("No match for")) {
                lookupTechniqueResult.setIsActive("Not Active");
                lookupTechniqueResult.setIsFraud("Fraud");
                lookupTechniqueResult.setResult(eachLine.trim());
                lookupTechniqueResult.setWebsiteurl("URL Not Registered on DNS Server - No Record Found");
                break;
            } else {
//                System.out.println("eachLine = " + eachLine);
                if (eachLine.startsWith("Domain Name:")) {
                    int index = eachLine.indexOf(":");
                    String websiteurl = eachLine.substring(index+1).trim().toLowerCase();
                    lookupTechniqueResult.setIsActive("Active");
                    lookupTechniqueResult.setIsFraud("Not Fraud");
                    lookupTechniqueResult.setResult(eachLine.trim());
                    lookupTechniqueResult.setWebsiteurl(websiteurl);
                    break;
                }
            }
        }
        return lookupTechniqueResult;
    }

    public static String saveWebsiteResultFile(String resultData) {
        String currentDir = System.getProperty("user.home");
        System.out.println("currentDir = " + currentDir);
        File folder = new File(currentDir, "/fds-data");
        if (!folder.exists()) {
            folder.mkdir();
        } else {
            String currentDate = new Date().toString();
            String fileName = "result_" + currentDate + ".txt";
            System.out.println(folder.getAbsolutePath());
            try {
                FileWriter fileWriter = new FileWriter(folder.getAbsolutePath() + "/" + fileName);
                fileWriter.write(resultData);
                fileWriter.close();
                return folder.getAbsolutePath() + "/" + fileName;
            } catch (Exception ex) {
                System.out.println("ex = " + ex.getMessage());
                return null;
            }
        }
        return null;
    }
}
