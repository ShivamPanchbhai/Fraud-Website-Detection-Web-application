/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.algorithm.controller;

/**
 *
 * @author aniket
 */
public class ResultModel {

    private String id;
    private String urlName;
    private String reasonforFraud;
    private Boolean isFraud;

    public String getReasonforFraud() {
        return reasonforFraud;
    }

    public void setReasonforFraud(String reasonforFraud) {
        this.reasonforFraud = reasonforFraud;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrlName() {
        return urlName;
    }

    public void setUrlName(String urlName) {
        this.urlName = urlName;
    }

    public Boolean getIsFraud() {
        return isFraud;
    }

    public void setIsFraud(Boolean isFraud) {
        this.isFraud = isFraud;
    }

    @Override
    public String toString() {
        return id; //To change body of generated methods, choose Tools | Templates.
    }
}
