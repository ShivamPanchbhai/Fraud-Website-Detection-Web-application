/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.algorithm.controller;

/**
 *
 * @author aniket
 */
public class LookupTechniqueResult {

    private String isFraud;
    private String isActive;
    private String websiteurl;
    private String result;
    private String resultFileDownloadLink;

    public String getIsFraud() {
        return isFraud;
    }

    public void setIsFraud(String isFraud) {
        this.isFraud = isFraud;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public String getWebsiteurl() {
        return websiteurl;
    }

    public void setWebsiteurl(String websiteurl) {
        this.websiteurl = websiteurl;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getResultFileDownloadLink() {
        return resultFileDownloadLink;
    }

    public void setResultFileDownloadLink(String resultFileDownloadLink) {
        this.resultFileDownloadLink = resultFileDownloadLink;
    }

    @Override
    public String toString() {
        return isActive + "\n" + isFraud + "\n" + websiteurl + "\n" + result + "\n" + resultFileDownloadLink+"\n"; //To change body of generated methods, choose Tools | Templates.
    }
}
