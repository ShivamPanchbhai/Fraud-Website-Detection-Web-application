/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.algorithm.controller;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author aniket
 */
public class HexadecimalValidator {

    private Pattern pattern;
    private Matcher matcher;
    private static final String HEXA_PATTERN = "[0-9a-fA-F]";

    public HexadecimalValidator() {
        pattern = Pattern.compile(HEXA_PATTERN);
    }

    /**
     * Validate hexa address with regular expression
     *
     * @param hexa hexa address for validation
     * @return true valid hexa address, false invalid hexa address
     */
    public boolean validate(final String ip) {
        matcher = pattern.matcher(ip);
        return matcher.matches();
    }
}
