/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.algorithm.controller;

import java.net.MalformedURLException;
import java.net.URL;

/**
 *
 * @author aniket
 */
public class LookupTechnique {

    public static LookupTechniqueResult findFraudWebsite(String websiteurl) {
        String url = parseURL(websiteurl);
        LookupTechniqueResult websiteResult = WhoIsLookup.validateWebsite(url.trim());
        if (websiteResult != null) {
            return websiteResult;
        }
        return null;
    }

    private static String parseURL(String websiteurl) {
        if (websiteurl.startsWith("www.")) {
            int beginIndex = websiteurl.indexOf(".");
            websiteurl = websiteurl.substring(beginIndex + 1).trim();
            return websiteurl;
        } else {
            try {

                URL url = new URL(websiteurl);
                String host = url.getHost();
                System.out.println("host: " + host);
                if (host.startsWith("www.")) {
                    int beginIndex = host.indexOf(".");
                    host = host.substring(beginIndex + 1).trim();
                    return host;
                }
                return host;
//            String protocol = url.getProtocol();
//            int port = url.getPort();
//            String path = url.getPath();
//            System.out.println("URL created: " + url);
//            System.out.println("protocol: " + protocol);
//            System.out.println("port: " + port);
//            System.out.println("path: " + path);

            } catch (MalformedURLException e) {
                System.out.println("Malformed URL: " + e.getMessage());
                return websiteurl.trim();
            }
        }
//        return null;
    }

    public static void main(String[] args) {
        String parseURL1 = parseURL("https://www.youtube.com");
        System.out.println("parseURL1 = " + parseURL1);
        String parseURL2 = parseURL("www.youtube.com");
        System.out.println("parseURL2 = " + parseURL2);
        String parseURL3 = parseURL("youtube.com");
        System.out.println("parseURL3 = " + parseURL3);
    }
}
