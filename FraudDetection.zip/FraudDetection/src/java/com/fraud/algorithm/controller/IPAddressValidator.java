/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.algorithm.controller;

/**
 *
 * @author aniket
 */
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IPAddressValidator {

    private Pattern pattern;
    private Matcher matcher;
    private static final String IPADDRESS_PATTERN =
            "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
            + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
            + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
            + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";

    public IPAddressValidator() {
        pattern = Pattern.compile(IPADDRESS_PATTERN);
    }

    /**
     * Validate ip address with regular expression
     *
     * @param ip ip address for validation
     * @return true valid ip address, false invalid ip address
     */
    public boolean validate(final String ip) {
        URL url = null;
        try {
            url = new URL(ip);
        } catch (MalformedURLException ex) {
            Logger.getLogger(IPAddressValidator.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (url != null) {
            String host = url.getHost();
            System.out.println("host = " + host);
            matcher = pattern.matcher(host.trim());
            return matcher.matches();
        }
        return false;
    }

    public static void main(String[] args) {
        IPAddressValidator addressValidator = new IPAddressValidator();
        boolean validate = addressValidator.validate("http://200.156.94.153/envio/atualizacao.php");
        System.out.println("validate = " + validate);
    }
}
