/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.home.controller;

import com.fraud.database.dto.UserInfoTableDTO;
import com.fraud.database.services.AdminInfoTableService;
import com.fraud.database.services.UserInfoTableService;
import com.fraud.home.model.AdminLoginModel;
import com.fraud.home.model.UserLoginModel;
import com.fraud.mail.controller.MailSender;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author aniket
 */
@Controller
public class HomeController {

    @RequestMapping(value = "setup_home.htm", method = RequestMethod.GET)
    public ModelAndView setupHome() {
        ModelAndView modelAndView = new ModelAndView("home/home");
        return modelAndView;
    }

    @RequestMapping(value = "setup_admin_login.htm", method = RequestMethod.GET)
    public ModelAndView setupAdminLogin() {
        ModelAndView modelAndView = new ModelAndView("home/admin_login");
        return modelAndView;
    }

    @RequestMapping(value = "setup_user_login.htm", method = RequestMethod.GET)
    public ModelAndView setupUserLogin() {
        ModelAndView modelAndView = new ModelAndView("home/user_login");
        return modelAndView;
    }

    @RequestMapping(value = "setup_user_registration.htm", method = RequestMethod.GET)
    public ModelAndView setupUserRegistration() {
        ModelAndView modelAndView = new ModelAndView("home/user_registration");
        return modelAndView;
    }

    @RequestMapping(value = "submit_admin_login.htm", method = RequestMethod.POST)
    public void submitAdminLogin(@ModelAttribute AdminLoginModel loginModel,
            HttpServletResponse response) {
        String username = loginModel.getUsername().trim();
        String password = loginModel.getPassword().trim();
        boolean status = AdminInfoTableService.verifyLogin(username, password);
        if (status) {
            try {
                response.sendRedirect("../admin/setup_dashboard.htm");
            } catch (Exception ex) {
                Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            try {
                response.sendRedirect("setup_admin_login.htm");
            } catch (Exception ex) {
                Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    @RequestMapping(value = "submit_continue_with_google_login.htm", method = RequestMethod.GET)
    public ModelAndView submitContinueWithGoogleLogin(@RequestParam("email") String emailId,
            @RequestParam("name") String name) {
        boolean status = UserInfoTableService.verifyEmailId(emailId);
        if (status) {
            ModelAndView modelAndView = new ModelAndView("home/user_registration");
            modelAndView.addObject("message", "This Email Id Already Registered...");
            return modelAndView;
        } else {
            Random random = new Random();
            int nextInt = random.nextInt(1000);
            String name1 = name.substring(0, 2);
            String password = "fds" + nextInt + name1;
            UserInfoTableDTO infoTableDTO = new UserInfoTableDTO();
            infoTableDTO.setActive(Boolean.TRUE);
            infoTableDTO.setEmailId(emailId);
            infoTableDTO.setName(name);
            infoTableDTO.setPassword(password);
            Integer userId = UserInfoTableService.add(infoTableDTO);
            MailSender.send(emailId, "Your Login Information", "User Name :- " + emailId + "  " + "Password :- " + password);
            ModelAndView modelAndView = new ModelAndView("home/user_login");
            return modelAndView;
        }
    }

    @RequestMapping(value = "submit_user_registration.htm", method = RequestMethod.POST)
    public ModelAndView submitUserRegistration(@ModelAttribute UserInfoTableInfo tableDTO,
            @RequestParam CommonsMultipartFile profileImage) {
        String emailId = tableDTO.getEmailId().trim();
        boolean status = UserInfoTableService.verifyEmailId(emailId);
        if (status) {
            ModelAndView modelAndView = new ModelAndView("home/user_registration");
            modelAndView.addObject("message", "This Email Id Already Registered...");
            return modelAndView;

        } else {
            Random random = new Random();
            int nextInt = random.nextInt(1000);
            String name = tableDTO.getName();
            String name1 = name.substring(0, 3);
            String password = "fds" + nextInt + name1;
            String phone = tableDTO.getPhone() + "";
            String pincode = tableDTO.getPincode() + "";
            UserInfoTableDTO infoTableDTO = new UserInfoTableDTO();
            infoTableDTO.setActive(Boolean.TRUE);
            infoTableDTO.setAddress(tableDTO.getAddress());
            infoTableDTO.setCity(tableDTO.getCity());
            infoTableDTO.setCountry(tableDTO.getCountry());
            infoTableDTO.setEmailId(emailId);
            infoTableDTO.setName(name);
            infoTableDTO.setPassword(password);
            infoTableDTO.setPhone(phone);
            infoTableDTO.setPincode(pincode);
            infoTableDTO.setState(tableDTO.getState());
            Integer userId = UserInfoTableService.add(infoTableDTO);
            try {
                if (profileImage != null) {
                    InputStream inputStream = profileImage.getInputStream();
                    String imageName = profileImage.getOriginalFilename();
                    File file1 = new File(imageName);
                    String ext = getExtension(file1);
                    String path = "/home/aniket/Project/2018-Proejcts/FraudDetection/web/style/" + userId;
                    File folder = new File(path);
                    if (!folder.exists()) {
                        boolean mkdirs = folder.mkdirs();
                    }
                    BufferedImage image_orig = getImage(inputStream);
                    setImage(image_orig, new File(image_path(path, "profile")), ext);
                }

            } catch (Exception ex) {
                Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
            MailSender.send(emailId, "Your Login Information", "User Name :- " + emailId + "  " + "Password :- " + password);
            ModelAndView modelAndView = new ModelAndView("home/user_login");
            modelAndView.addObject("message", "Registration Successfully Completed...");
            return modelAndView;
        }
    }

    private String image_path(String path, String name) {
        return path + "/" + name;
    }

    public static String getExtension(File f) {
        String s = f.getName();
        int i = s.lastIndexOf('.');
        if (i > 0 && i < s.length() - 1) {
            return s.substring(i + 1).toLowerCase();
        }
        return "";
    }

    private boolean setImage(BufferedImage image, File file, String ext) {
        try {
            file.delete(); //delete resources used by the File
            ImageIO.write(image, ext, file);
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "File could not be saved!", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private BufferedImage getImage(InputStream f) {
        BufferedImage image = null;
//        File file = new File(f);
        try {
            image = ImageIO.read(f);
        } catch (Exception ex) {
            System.out.println("ex = " + ex);
            JOptionPane.showMessageDialog(null,
                    "Image could not be read!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return image;
    }

    @RequestMapping(value = "submit_user_login.htm", method = RequestMethod.POST)
    public void submitUserLogin(@ModelAttribute UserLoginModel loginModel,
            HttpServletRequest request, HttpServletResponse response) {
        String username = loginModel.getUsername().trim();
        String password = loginModel.getPassword().trim();
        boolean status = UserInfoTableService.verifyLogin(username, password);
        if (status) {
            try {
                request.getSession().setAttribute("useremail", username);
                response.sendRedirect("../user/setup_dashboard.htm");
            } catch (Exception ex) {
                Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            try {
                response.sendRedirect("setup_user_login.htm");
            } catch (Exception ex) {
                Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }
}
