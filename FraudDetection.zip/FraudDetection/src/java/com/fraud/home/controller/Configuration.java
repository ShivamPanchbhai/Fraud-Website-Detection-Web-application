/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.home.controller;

/**
 *
 * @author aniket
 */
public class Configuration {

    private static final String DATA_FOLDER_NAME = "/FDSData";
    private static final String FILE_INFO_DATA_FOLDER_NAME = "/data";

    public static String getHomeDir() {
        String homeDir = System.getProperty("user.home");
        return homeDir;
    }

    public static String getDataFolderPath() {
        String homeDir = getHomeDir();
        String dataFolder = homeDir + DATA_FOLDER_NAME;
        return dataFolder;
    }

    public static String getFileInfoDataFolderPath() {
        String dataFolderPath = getDataFolderPath();
        String fileInfoDataFolder = dataFolderPath + FILE_INFO_DATA_FOLDER_NAME + "/";
        return fileInfoDataFolder;
    }


    public static void main(String[] args) {
        String homeDir = getHomeDir();
        System.out.println("homeDir = " + homeDir);
        String dataFolderPath = getDataFolderPath();
        System.out.println("dataFolderPath = " + dataFolderPath);
        String fileInfoDataFolderPath = getFileInfoDataFolderPath();
        System.out.println("fileInfoDataFolderPath = " + fileInfoDataFolderPath);
    }
}
