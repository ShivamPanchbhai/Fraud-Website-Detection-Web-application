/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fraud.admin.controller;

import com.fraud.database.dto.UserInfoTableDTO;
import com.fraud.database.services.UserInfoTableService;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author aniket
 */
@Controller
public class AdminController {

    @InitBinder
    public void initBinder(WebDataBinder webDataBinder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);
        webDataBinder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    @RequestMapping(value = "setup_dashboard.htm", method = RequestMethod.GET)
    public ModelAndView setupDashboard() {
        ModelAndView modelAndView = new ModelAndView("admin/dashboard");
        return modelAndView;
    }

    @RequestMapping(value = "logout.htm", method = RequestMethod.GET)
    public void logout(HttpServletRequest request, HttpServletResponse response) {
        try {
            request.getSession().invalidate();
            response.sendRedirect("../home/setup_admin_login.htm");
        } catch (Exception ex) {
            Logger.getLogger(AdminController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @RequestMapping(value = "setup_view_user_list.htm", method = RequestMethod.GET)
    public ModelAndView setupViewUserList() {
        ArrayList<UserInfoTableDTO> list = UserInfoTableService.getUserInfoDTOList();
        ModelAndView modelAndView = new ModelAndView("admin/user_list");
        modelAndView.addObject("list", list);
        return modelAndView;
    }

    @RequestMapping(value = "submit_delete.htm", method = RequestMethod.GET)
    public ModelAndView deleteUser(@RequestParam("userId") Integer id) {
        UserInfoTableDTO userInfoDTOById = UserInfoTableService.getUserInfoDTOById(id);
        userInfoDTOById.setActive(Boolean.FALSE);
        UserInfoTableService.update(userInfoDTOById);
        ModelAndView modelAndView = new ModelAndView("admin/success");
        return modelAndView;
    }
}
