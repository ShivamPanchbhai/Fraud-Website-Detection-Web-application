/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import org.apache.commons.net.whois.WhoisClient;

/**
 *
 * @author aniket
 */
public class WhoIsTest {
    public static void main(String[] args) {
 
//      String domain = "ibgitechnology.com";
//      String domain = "google.com";
//      String domain = "aniketkohaleak.com";
      String domain = "ibgitechnology.org";
      StringBuilder sb = new StringBuilder("");
      WhoisClient wic = new WhoisClient();
      try {
         wic.connect(WhoisClient.DEFAULT_HOST);
         String whoisData1 = wic.query("=" + domain);
         sb.append(whoisData1);
         wic.disconnect();
      } catch (Exception e) {
         e.printStackTrace();
      }
      System.out.println(sb.toString());
   }
}
