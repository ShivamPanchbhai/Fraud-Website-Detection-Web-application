///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package test;
//
//import java.net.URI;
//import java.net.URISyntaxException;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//
///**
// *
// * @author aniket
// */
//public class Test2 {
//
//    public static void main(String[] args) {
////        String url = "https://topshotmultidigitalservices.com/464/21/login.php?wa=wsignin1.0&rpsnv=13&ct=1506170093&rver=6.7.6643.0&wp=MBI_SSL_SHARED&wreply=inbox&lc=1033&id=64855&mkt=en-us&cbcxt=mai";
////        String url = "http://ibgitechnology.com/";
////        String url = "http://sagawa-opi.com/pp.html";
//        String url = "http://onde-447.ga/update/approve_it_confirmation_0.php";
////        String url = "http://el-change.com/";
//        int length = url.length();
//        System.out.println("length = " + length);
//        double arr[] = new double[length];
//        for (int i = 0; i < length; i++) {
//            arr[i] = i;
//        }
//        Max max = new Max();
//        Median median = new Median();
//        double evaluate = median.evaluate(arr);
//        System.out.println("evaluate = " + evaluate);
//
//        try {
//        URI  uri = new URI(url);
//        String domain = uri.getHost();
//            System.out.println("domain = " + domain);
//            System.out.println("domain = " + domain.length());
//        } catch (URISyntaxException ex) {
//            Logger.getLogger(Test2.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//}
