drop database if exists fdsdb;
create database fdsdb;
use fdsdb;

drop table if exists admin_info_table;
create table admin_info_table
(
id int(10) primary key auto_increment,
name text,
address text,
city text,
state text,
country text,
pincode text,
phone text,
emailId text,
password text,
active tinyint(1)
);

INSERT INTO admin_info_table (`name`, address, city, `state`, country, pincode, phone, emailId, password, active) VALUES ('Admin', 'Ramtek', 'Nagpur', 'Maharashtra', 'India', '441401', '1234567890', 'dldgroup2017@gmail.com', 'admin', 1);


drop table if exists user_info_table;
create table user_info_table
(
id int(10) primary key auto_increment,
name text,
address text,
city text,
state text,
country text,
pincode text,
phone text,
emailId text,
password text,
active tinyint(1)
);
